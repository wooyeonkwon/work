from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2022D_2'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/Muon/Run2022D-27Jun2023-v2/AOD'
config.Data.unitsPerJob = 100
config.Data.splitting = 'LumiBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.publication = False
config.section_('Site')
config.Site.blacklist = ['T2_US_MIT']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
