from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2023B0'
config.section_('JobType')
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['data.root']
config.JobType.psetName = 'conf.py'
config.JobType.maxMemoryMB = 2000
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDataset = '/Muon0/Run2023B-PromptReco-v1/AOD'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
