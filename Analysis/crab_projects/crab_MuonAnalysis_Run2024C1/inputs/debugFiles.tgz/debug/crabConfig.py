from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2024C1'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.inputDataset = '/Muon1/Run2024C-PromptReco-v1/AOD'
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
