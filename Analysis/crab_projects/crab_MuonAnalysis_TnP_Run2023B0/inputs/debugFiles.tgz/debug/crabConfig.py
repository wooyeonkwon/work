from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_TnP_Run2023B0'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/Muon0/Run2023B-PromptReco-v1/AOD'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
