from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2024B0'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 100
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDataset = '/Muon0/Run2024B-PromptReco-v1/AOD'
config.section_('Site')
config.Site.blacklist = ['T2_US_MIT']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
