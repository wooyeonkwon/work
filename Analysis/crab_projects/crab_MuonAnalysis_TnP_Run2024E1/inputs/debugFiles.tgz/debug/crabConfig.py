from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_TnP_Run2024E1'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.JobType.maxMemoryMB = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon1/Run2024E-PromptReco-v2/AOD'
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.unitsPerJob = 100
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
