from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2024F1'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.numCores = 1
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2000
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.inputDataset = '/Muon1/Run2024F-PromptReco-v1/AOD'
config.Data.unitsPerJob = 100
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.blacklist = ['T2_US_MIT']
config.section_('User')
config.section_('Debug')
