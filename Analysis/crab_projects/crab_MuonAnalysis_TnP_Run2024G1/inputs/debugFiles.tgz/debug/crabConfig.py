from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_TnP_Run2024G1'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.JobType.numCores = 1
config.JobType.outputFiles = ['data.root']
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 100
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon1/Run2024G-PromptReco-v1/AOD'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
