from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2022D'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/Muon/Run2022D-27Jun2023-v2/AOD'
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 100
config.Data.splitting = 'LumiBased'
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.blacklist = ['T2_US_MIT']
config.section_('User')
config.section_('Debug')
