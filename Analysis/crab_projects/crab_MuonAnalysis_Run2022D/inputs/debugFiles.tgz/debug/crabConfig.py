from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2022D'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon/Run2022D-27Jun2023-v2/AOD'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
