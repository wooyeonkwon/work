from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2022E'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.JobType.maxMemoryMB = 8000
config.JobType.numCores = 4
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.splitting = 'LumiBased'
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 100
config.Data.inputDataset = '/Muon/Run2022E-27Jun2023-v1/AOD'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.blacklist = ['T2_US_MIT']
config.section_('User')
config.section_('Debug')
