from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_TnP_Run2022D'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'conf.py'
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.JobType.outputFiles = ['data.root']
config.section_('Data')
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.inputDataset = '/Muon/Run2022D-27Jun2023-v2/AOD'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
