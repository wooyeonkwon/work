from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_TnP_Run2022C'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['data.root']
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.inputDataset = '/Muon/Run2022C-27Jun2023-v1/AOD'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 100
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
