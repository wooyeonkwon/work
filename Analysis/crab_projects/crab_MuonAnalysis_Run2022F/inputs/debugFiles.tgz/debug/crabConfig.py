from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2022F'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.numCores = 1
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['data.root']
config.JobType.maxMemoryMB = 2000
config.section_('Data')
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.unitsPerJob = 100
config.Data.inputDataset = '/Muon/Run2022F-PromptReco-v1/AOD'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.blacklist = ['T2_US_MIT']
config.section_('User')
config.section_('Debug')
