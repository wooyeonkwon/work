from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2022F'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 4
config.JobType.psetName = 'conf.py'
config.JobType.maxMemoryMB = 8000
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.inputDataset = '/Muon/Run2022F-PromptReco-v1/AOD'
config.Data.splitting = 'LumiBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.blacklist = ['T2_US_MIT']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
