from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2024E0'
config.section_('JobType')
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/Muon0/Run2024E-PromptReco-v2/AOD'
config.Data.unitsPerJob = 100
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
