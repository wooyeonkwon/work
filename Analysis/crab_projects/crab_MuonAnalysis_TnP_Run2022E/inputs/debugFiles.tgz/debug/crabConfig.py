from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_TnP_Run2022E'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon/Run2022E-27Jun2023-v1/AOD'
config.Data.unitsPerJob = 100
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
