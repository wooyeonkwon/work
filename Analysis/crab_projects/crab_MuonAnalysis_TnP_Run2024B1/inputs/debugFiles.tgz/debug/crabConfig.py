from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_TnP_Run2024B1'
config.section_('JobType')
config.JobType.maxMemoryMB = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'conf.py'
config.JobType.outputFiles = ['data.root']
config.JobType.numCores = 1
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/Muon1/Run2024B-PromptReco-v1/AOD'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
