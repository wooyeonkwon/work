import FWCore.ParameterSet.Config as cms

analysis = cms.EDAnalyzer('Analysis',
  muons = cms.InputTag('muons'),
  triggerResults = cms.InputTag('TriggerResults'),
  vertices = cms.InputTag('offlinePrimaryVertices'),
  hltPath = cms.string('HLT_IsoMu24_v*'),
  mightGet = cms.optional.untracked.vstring
)
