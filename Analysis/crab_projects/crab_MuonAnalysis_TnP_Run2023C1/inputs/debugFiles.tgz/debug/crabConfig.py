from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_TnP_Run2023C1'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.unitsPerJob = 100
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.inputDataset = '/Muon1/Run2023C-PromptReco-v4/AOD'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
