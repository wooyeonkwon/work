from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2023B1'
config.section_('JobType')
config.JobType.maxMemoryMB = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['data.root']
config.JobType.psetName = 'conf.py'
config.JobType.numCores = 1
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon1/Run2023B-PromptReco-v1/AOD'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
