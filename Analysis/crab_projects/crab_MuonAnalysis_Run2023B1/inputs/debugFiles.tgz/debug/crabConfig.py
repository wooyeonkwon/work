from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2023B1'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 5000
config.JobType.numCores = 1
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.unitsPerJob = 100
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.inputDataset = '/Muon1/Run2023B-PromptReco-v1/AOD'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.section_('Site')
config.Site.blacklist = ['T2_US_MIT']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
