from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2022G'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.Data.unitsPerJob = 100
config.Data.publication = False
config.Data.inputDataset = '/Muon/Run2022G-PromptReco-v1/AOD'
config.Data.splitting = 'LumiBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.section_('Site')
config.Site.blacklist = ['T2_US_MIT']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
