from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2024D0'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/Muon0/Run2024D-PromptReco-v1/AOD'
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
