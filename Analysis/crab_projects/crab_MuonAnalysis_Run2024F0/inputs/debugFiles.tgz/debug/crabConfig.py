from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2024F0'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['data.root']
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2024_378981_385194_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.inputDataset = '/Muon0/Run2024F-PromptReco-v1/AOD'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.blacklist = ['T2_US_MIT']
config.section_('User')
config.section_('Debug')
