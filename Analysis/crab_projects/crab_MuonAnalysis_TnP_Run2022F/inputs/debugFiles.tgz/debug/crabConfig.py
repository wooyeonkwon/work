from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_TnP_Run2022F'
config.section_('JobType')
config.JobType.numCores = 1
config.JobType.outputFiles = ['data.root']
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2000
config.section_('Data')
config.Data.publication = False
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 100
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDataset = '/Muon/Run2022F-PromptReco-v1/AOD'
config.Data.lumiMask = 'Cert_Collisions2022_355100_362760_Golden.json'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
