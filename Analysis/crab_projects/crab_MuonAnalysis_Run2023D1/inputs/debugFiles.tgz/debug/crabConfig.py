from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2023D1'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['data.root']
config.JobType.numCores = 1
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.inputDataset = '/Muon1/Run2023D-PromptReco-v2/AOD'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
