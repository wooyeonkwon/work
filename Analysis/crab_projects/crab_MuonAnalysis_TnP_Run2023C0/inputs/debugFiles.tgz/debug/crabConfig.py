from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_TnP_Run2023C0'
config.section_('JobType')
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'conf.py'
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.section_('Data')
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.inputDataset = '/Muon0/Run2023C-PromptReco-v4/AOD'
config.Data.unitsPerJob = 100
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
