from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_Run2023D0'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.maxMemoryMB = 2000
config.JobType.outputFiles = ['data.root']
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.inputDataset = '/Muon0/Run2023D-PromptReco-v2/AOD'
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.unitsPerJob = 100
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.blacklist = ['T2_US_MIT']
config.section_('User')
config.section_('Debug')
