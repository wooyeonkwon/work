from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_Run2023D0'
config.section_('JobType')
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.JobType.outputFiles = ['data.root']
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2023_366442_370790_Golden.json'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.unitsPerJob = 100
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/Muon0/Run2023D-PromptReco-v2/AOD'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
