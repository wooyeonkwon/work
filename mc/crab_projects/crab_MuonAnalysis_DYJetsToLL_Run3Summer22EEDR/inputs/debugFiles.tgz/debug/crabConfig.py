from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'MuonAnalysis_DYJetsToLL_Run3Summer22EEDR'
config.section_('JobType')
config.JobType.psetName = 'conf.py'
config.JobType.maxMemoryMB = 2000
config.JobType.numCores = 1
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['mc.root']
config.section_('Data')
config.Data.inputDataset = '/DYJetsToLL_M-50_TuneCP5_13p6TeV-madgraphMLM-pythia8/Run3Summer22EEDRPremix-forPOG_124X_mcRun3_2022_realistic_postEE_v1-v3/AODSIM'
config.Data.publication = False
config.Data.unitsPerJob = 100
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
