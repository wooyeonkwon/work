from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'MuonAnalysis_QCD_Run3Summer22EEDR'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.maxMemoryMB = 2000
config.JobType.psetName = 'conf.py'
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.outputFiles = ['mc.root']
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/wkwon/AnalysisResults/'
config.Data.unitsPerJob = 100
config.Data.publication = False
config.Data.inputDataset = '/QCD_PT-15to7000_TuneCP5_13p6TeV_pythia8/Run3Summer22EEDRPremix-castor_124X_mcRun3_2022_realistic_postEE_v1-v2/AODSIM'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
